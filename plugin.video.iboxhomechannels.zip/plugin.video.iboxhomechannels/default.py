import xbmc,xbmcplugin,xbmcgui
import sys, os, pwd
import urllib,urllib2 , re
import subprocess

LinkDescription = []
LinkURL = []

# change the path below to point to your Toppt .rec files
recpath='~/.xbmc/userdata/'
jpath='~/.xbmc/userdata/'
#name='iBoxChannels.js'
name='iBoxUsrChannels.js'
#global chPath=''

# magic; id of this plugin - cast to integer
thisPlugin = int(sys.argv[1])


global gDir
global dirCounter

def findItemInList(f, seq):
  """Return first item in sequence where f(item) == True."""
#  print("findItemInList-A::"+str(f)+" ::: "+str(seq))
  for item in seq:
#    print(str(item)+" ::: ")
    mItemStr=str(item)
#    if item == f: 
    if mItemStr.find(f) > -1:
#      print "AAAA"
#      print item
#      print f
#      print "BBBB"

      myEName=item
#      myEName0=myEName.split("'")
#      print len(myEName)
      myEName0=str(myEName[1])
      myEName1=myEName0.split(':')
      myEName2=myEName1[1].strip()
      myEName3=myEName2.replace("'", '')
#      print "findItemInList::myEName3:"+myEName3
#      print "BBBB"

      return myEName3

def getDirectoryById(gDirectoryId):
	global gDir

#	print "gDirectoryId::"+str(gDirectoryId)
	gDirElement="id:"+gDirectoryId
#	print("getDirectoyById::gDirElement :"+str(gDirElement))
#	myItem=findItemInList(gDirElement,gDir[:-1])
        myItem=findItemInList(gDirElement,gDir)
#	print "getDirectoyById::gDirElement::"+str(myItem)
	return myItem

def createDirectory(myDir, myDirId=None):
        global thisPlugin
        myDirectory=myDir
        #print len(myDirectory)
        #print myDirectory[0]
        #print myDirectory[1]
        #print myDirectory[2]
        #print myDirectory[3]
        myDName=str(myDirectory[1])
#	print str(myDName)
        myDName1=myDName.split(':')
#        print str(myDName1)
        myDName2=myDName1[1].strip()
#        print str(myDName2)
        myDName3=myDName2.replace("'", '')
#        print str(myDName3)
#        print(myDName3)

        listItemFull = xbmcgui.ListItem(myDName3)
# #        xbmcplugin.addDirectoryItem(thisPlugin,myDName3,listitem=listItemFull,isFolder=True)
        return myDName3

def createElements(myElem, myLangPack):
        global thisPlugin
#	global gDir
	global dirCounter

        myElement=myElem
#        print myElement

        # print len(myElement)
        myEName=str(myElement[4])
        myEName1=myEName.split(':')
        myEName2=myEName1[1].strip()
        myEName3=myEName2.replace("'", '')
#        print(myEName3)

	myELang=str(myElement[5])
        myELang1=myELang.split(':')
        myELang2=myELang1[1].strip()
#	myEName3=myEName2.replace("'", '')
#	print "myELang2::"+str(myELang2)

        myEUrl=str(myElement[3])
        myEUrl1=myEUrl.split(':',1)
        myEUrl2=myEUrl1[1].strip()
        myEUrl3=myEUrl2.replace("'", '')

        myELogo=str(myElement[1])
        myELogo1=myELogo.split(':',1)
        myELogo2=myELogo1[1].strip()
        myELogo3=myELogo2.replace("'", '')
#	print myELogo3


	if (myLangPack == 'English') and (myLangPack == str(getDirectoryById(myELang2))):
		listItemFull=xbmcgui.ListItem(myEName3+' : '+str(getDirectoryById(myELang2)), iconImage=myELogo3, thumbnailImage=myELogo3, path=str(getDirectoryById(myELang2)))
                xbmcplugin.addDirectoryItem(thisPlugin,myEUrl3,listitem=listItemFull)
		print ("ADD English "+myEName3+" :: "+myLangPack+" : "+str(getDirectoryById(myELang2)))
        elif (myLangPack == 'German') and (myLangPack == str(getDirectoryById(myELang2))):
                listItemFull=xbmcgui.ListItem(myEName3+' : '+str(getDirectoryById(myELang2)), iconImage=myELogo3, thumbnailImage=myELogo3, path=str(getDirectoryById(myELang2)))
                xbmcplugin.addDirectoryItem(thisPlugin,myEUrl3,listitem=listItemFull)
                print ("ADD German "+myEName3+" :: "+myLangPack+" : "+str(getDirectoryById(myELang2)))
        elif (myLangPack == 'Urdu') and (myLangPack == str(getDirectoryById(myELang2))):
                listItemFull=xbmcgui.ListItem(myEName3+' : '+str(getDirectoryById(myELang2)), iconImage=myELogo3, thumbnailImage=myELogo3, path=str(getDirectoryById(myELang2)))
                xbmcplugin.addDirectoryItem(thisPlugin,myEUrl3,listitem=listItemFull)
                print ("ADD Urdu "+myEName3+" :: "+myLangPack+" : "+str(getDirectoryById(myELang2)))
        elif (myLangPack == 'Hindi') and (myLangPack == str(getDirectoryById(myELang2))):
                listItemFull=xbmcgui.ListItem(myEName3+' : '+str(getDirectoryById(myELang2)), iconImage=myELogo3, thumbnailImage=myELogo3, path=str(getDirectoryById(myELang2)))
                xbmcplugin.addDirectoryItem(thisPlugin,myEUrl3,listitem=listItemFull)
                print ("ADD Hindi "+myEName3+" :: "+myLangPack+" : "+str(getDirectoryById(myELang2)))
        elif (myLangPack == 'Tamil') and (myLangPack == str(getDirectoryById(myELang2))):
                listItemFull=xbmcgui.ListItem(myEName3+' : '+str(getDirectoryById(myELang2)), iconImage=myELogo3, thumbnailImage=myELogo3, path=str(getDirectoryById(myELang2)))
                xbmcplugin.addDirectoryItem(thisPlugin,myEUrl3,listitem=listItemFull)
                print ("ADD Tamil "+myEName3+" :: "+myLangPack+" : "+str(getDirectoryById(myELang2)))
        elif (myLangPack == 'Arabic') and (myLangPack == str(getDirectoryById(myELang2))):
                listItemFull=xbmcgui.ListItem(myEName3+' : '+str(getDirectoryById(myELang2)), iconImage=myELogo3, thumbnailImage=myELogo3, path=str(getDirectoryById(myELang2)))
                xbmcplugin.addDirectoryItem(thisPlugin,myEUrl3,listitem=listItemFull)
                print ("ADD Arabic "+myEName3+" :: "+myLangPack+" : "+str(getDirectoryById(myELang2)))
        elif (myLangPack == 'Turkish') and (myLangPack == str(getDirectoryById(myELang2))):
                listItemFull=xbmcgui.ListItem(myEName3+' : '+str(getDirectoryById(myELang2)), iconImage=myELogo3, thumbnailImage=myELogo3, path=str(getDirectoryById(myELang2)))
                xbmcplugin.addDirectoryItem(thisPlugin,myEUrl3,listitem=listItemFull)
                print ("ADD Turkish "+myEName3+" :: "+myLangPack+" : "+str(getDirectoryById(myELang2)))
        elif (myLangPack == 'French') and (myLangPack == str(getDirectoryById(myELang2))):
                listItemFull=xbmcgui.ListItem(myEName3+' : '+str(getDirectoryById(myELang2)), iconImage=myELogo3, thumbnailImage=myELogo3, path=str(getDirectoryById(myELang2)))
                xbmcplugin.addDirectoryItem(thisPlugin,myEUrl3,listitem=listItemFull)
                print ("ADD French "+myEName3+" :: "+myLangPack+" : "+str(getDirectoryById(myELang2)))
        elif (myLangPack == 'All'): # and (myLangPack == str(getDirectoryById(myELang2))):
                listItemFull=xbmcgui.ListItem(myEName3+' : '+str(getDirectoryById(myELang2)), iconImage=myELogo3, thumbnailImage=myELogo3, path=str(getDirectoryById(myELang2)))
                xbmcplugin.addDirectoryItem(thisPlugin,myEUrl3,listitem=listItemFull)
#                print ("ADD All "+myLangPack+" : "+str(getDirectoryById(myELang2)))
	else:
		#print ("Nothing to Add. Wanted: "+myLangPack+" and got: "+myEName3+" :: "+str(getDirectoryById(myELang2)))
		print (" ")
	
#        print(myELang2)+(myEName2)+(myEUrl3)
#        print(str(dirCounter))+(myELang2)+(myEName2)
#	print(gDir[:-1])

def createJsonListing():
	global thisPlugin
	global gDir
	global dirCounter

	gDir = []
	dirCounter = 0
	
	uIdLineArray = "test12345"
	Base_URL = "http://www.fxworks.de/py/todo.txt?ct=chl&cpun=tester&cppw=testerpw&dvid="+uIdLineArray
	WebSock = urllib.urlopen(Base_URL) # Opens a 'Socket' to URL
	WebHTML = WebSock.read() # Reads Contents of URL and saves to Variable
	WebSock.close() # Closes connection to url

	WebHTML = WebHTML.replace('<br>', '\n')
	WebHTML = WebHTML.replace('&nbsp;', '')
	# print WebHTML
	os.system('echo "'+WebHTML+'" > '+recpath+'iBH.json')
	# print myUN
	print 'WEB-END ---------------------------------------------'
	# NEW CODE-END

	print 'START: **********************************'
	path=xbmc.translatePath(jpath)
	# (os.path.join(jpath,name))
	# fullFilename=path+name
	fullFilename=recpath+'iBH.json'
	log = open(fullFilename, 'r')
        # load our text file into an array for easy access.
        for line in log:
        	# Output all of the array text file to the screen.
		#print 'XXX'
		lineStripped = line.strip(' ')
                lineStripped = lineStripped.strip('\t')
##		print("MAIN-LINE: "+str(lineStripped))
		lineArray = lineStripped.split(',')
		print '========================================================================================================'
##                print("LINEARRAY: "+str(lineArray[0]))
                print("LINEARRAY: "+str(lineArray))
##                print("LINEARRAY-LEN: "+str(len(lineArray)))
                if (len(lineArray) == 4) or (len(lineArray) == 5):
		#if len(lineArray) == 4:
			print 'inLineArray-4-5'
#			dirCounter += 1
			createDirectory(lineArray)
			# print str(createDirectory(lineArray))
			# print str(dirCounter)+" <-- dirCounter"
			gDir.append(lineArray)
                        dirCounter += 1
                        #print ">>"+str(createDirectory(lineArray))+"<<"
			#print("dirCounter::"+str(dirCounter)+" :: lineArray ="+str(lineArray)+" :: gDir = "+str(gDir[:-1]))
#			print("dirCounter::"+str(dirCounter)+" :: lineArray ="+str(lineArray)+" :: gDir = "+str(gDir))
##			print("DIR: "+str(lineArray))
                elif (len(lineArray) == 7) or (len(lineArray) == 8):
		#elif len(lineArray) == 7:
			print 'inLineArray-7-8'
			langPackage = sys.argv[2]
			langPackage = langPackage.split('=')[1]
                        #print langPackage
			createElements(lineArray, langPackage)

        log.close()

        xbmcplugin.endOfDirectory(thisPlugin)
        print 'END: **********************************'


'''
def sendToXbmc(listing):

	#access global plugin id
	global thisPlugin

	# send each item to xbmc
	for item in listing:
		listItem = xbmcgui.ListItem(item)

		# = xbmcgui.ListItem(chPath)
		# xbmcplugin.addDirectoryItem(thisPlugin,'',listItem)
		xbmcplugin.addDirectoryItem(thisPlugin,'',listitem=listItem)

	# tell xbmc we have finished creating the directory listing
	# xbmcplugin.addSortMethod(thisPlugin=int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.endOfDirectory(thisPlugin)
'''

createJsonListing()
